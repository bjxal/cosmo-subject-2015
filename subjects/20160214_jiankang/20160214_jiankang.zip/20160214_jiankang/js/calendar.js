$(function(){
    var ths = $("#Text2")[0];
    calendar.show({
        id: $("#Text2")[0], ok: function () {}
    });
});