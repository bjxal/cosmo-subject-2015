var focus_list = [
    {
        content: '<a href="activity_2.html"><div class="act_top_c"><p class="act_top_c_1">�ۺ�������</p><p>2015-09-11</p><p>�й�.����</p></div><img src="./testImg/1.jpg"/></a>'
    },
    {
        content: '<a href="activity_2.html"><div class="act_top_c"><p class="act_top_c_1">�ۺ�������</p><p>2015-09-11</p><p>�й�.����</p></div><img src="./testImg/1.jpg"/></a>'
    },
    {
        content: '<a href="activity_2.html"><div class="act_top_c"><p class="act_top_c_1">�ۺ�������</p><p>2015-09-11</p><p>�й�.����</p></div><img src="./testImg/1.jpg"/></a>'
    }
];
var focus_list2 = [
    {
        content: '<a href="activity_2.html"><div class="act_top_c"><p class="act_top_c_1">�ۺ�������</p></div><img src="./testImg/2.jpg"/></a>'
    },
    {
        content: '<a href="activity_2.html"><div class="act_top_c"><p class="act_top_c_1">�ۺ�������</p></div><img src="./testImg/2.jpg"/></a>'
    },
    {
        content: '<a href="activity_2.html"><div class="act_top_c"><p class="act_top_c_1">�ۺ�������</p></div><img src="./testImg/2.jpg"/></a>'
    }
];
var focus_list3 = [
    {
        content: '<a href="activity_2.html" class="run_c"><div class="order_c"><p>RUN</p><span class="act_tit">�ۺ�������</span><img src="testImg/2.jpg" class="width_100"/></div></a>'
    },
    {
        content: '<a href="activity_2.html" class="run_c"><div class="order_c"><p>RUN</p><span class="act_tit">�ۺ�������</span><img src="testImg/2.jpg" class="width_100"/></div></a>'
    },
    {
        content: '<a href="activity_2.html" class="run_c"><div class="order_c"><p>RUN</p><span class="act_tit">�ۺ�������</span><img src="testImg/2.jpg" class="width_100"/></div></a>'
    }
];
$(document).ready(function(){
    //���ذ�ť
    $(".top,.tit").on("click",function(e){
        var $tar = $(e.target);
        if($tar[0].nodeName.toLowerCase()=="a") return;
        history.back(-1);
    })
    var cname = $("body").attr("class");
    if(cname.indexOf("tips_1")!=-1){
        var S = new iSlider(document.getElementById('iSlider-wrapper-news3'), focus_list, {
            isLooping: 1,
            isOverspread: 1,
            isAutoplay: 0,
            animateTime: 800,
            animateType: 'rotate',
            onslidechanged:function() {
                $(".focus_circle a").eq(S.slideIndex).addClass("cur").siblings().removeClass("cur");
            }
        });
    }
    else if(cname.indexOf("index_1")!=-1){
        var S = new iSlider(document.getElementById('iSlider-wrapper-news'), focus_list, {
            isLooping: 1,
            isOverspread: 1,
            isAutoplay: 0,
            animateTime: 800,
            animateType: 'rotate',
            onslidechanged:function() {
                $(".focus_circle a").eq(S.slideIndex).addClass("cur").siblings().removeClass("cur");
            }
        });
    }
    else if(cname.indexOf("welfare")!=-1){
        var S = new iSlider(document.getElementById('iSlider-wrapper-news3'), focus_list3, {
            isLooping: 1,
            isOverspread: 1,
            isAutoplay: 0,
            animateTime: 800,
            animateType: 'rotate',
            onslidechanged:function() {}
        });
    }
    else if(cname.indexOf("result")!=-1){
        var S = new iSlider(document.getElementById('iSlider-wrapper-news2'), focus_list2, {
            isLooping: 1,
            isOverspread: 1,
            isAutoplay: 0,
            animateTime: 800,
            animateType: 'rotate',
            onslidechanged:function() {}
        });
        $(".index_result .login_btn").on("click",function(e){
            $(".index_result .share_mine").fadeIn();
        });
        $(".share_mine").on("click",function(e){
            var cname = $(e.target).attr("class")||"";
            if(cname.indexOf("share_icon")==-1){
                $(".index_result .share_mine").fadeOut();
            }
            else{}
        });
    }
    else if(cname.indexOf("activity_detail")!=-1){
        var S = new iSlider(document.getElementById('iSlider-wrapper-news3'), focus_list2, {
            isLooping: 1,
            isOverspread: 1,
            isAutoplay: 0,
            animateTime: 800,
            animateType: 'rotate',
            onslidechanged:function() {}
        });
        $(".index_result .login_btn").on("click",function(e){
            $(".index_result .share_mine").fadeIn();
        });
        $(".share_mine").on("click",function(e){
            var cname = $(e.target).attr("class")||"";
            if(cname.indexOf("share_icon")==-1){
                $(".index_result .share_mine").fadeOut();
            }
            else{}
        });
    }
    //welfare_5
    $("#welfare_img").on("change",function(e){
        var $tar = $(e.target);
        var imgUrl = $("#ImgPr").attr("src");
        //ajax ��ͼ
        setTimeout(function(){
            //console.log($("#welfare_img")[0].files[0]);
            //return;
            window.location.href = $tar.prev().data("nexturl")+".html";
        },500)
    });
    /*��һ��*/
    $(".login_btn").on("click",function(e){
        var $tar = $(e.target);
        var nextUrl = $tar.data("nexturl");
        if(nextUrl){
            window.location.href=nextUrl+".html";
        }
    })
    $(".bm_date").on("click",function(e){
        var $tar = $(e.target);
        var nextUrl = $tar.data("nexturl");
        if(nextUrl){
            window.location.href=nextUrl+".html";
        }
    })
    /*��ϵ�ͷ�*/
    $(".phone").on("click",function(e){
        var $tar = $(e.target);
        var $par = $tar.parents("body");
        $par.find(".phone_tips").fadeIn();
    })
    //��ά��
    $(".ewm").on("click",function(e){
        var $tar = $(e.target);
        var url = $tar.data("imgurl");
        $(".ewm_c img").attr("src",url);
        $(".pop.ewm_c").fadeIn();
    });
    /*��ʾȫ������*/
    $(".show_all").on("click",function(e){
        var $tar = $(e.target);
        $tar.parent().toggleClass("height_460");
        $tar.toggleClass("up");
    });
    $(".close_tip,.pop").on("click",function(e){
        var $tar = $(e.target);
        var $par = $tar.parents("body");
        $par.find(".pop").fadeOut();
    })
    /*����*/
    $(".share_mine").on("touchend",function(e){
        $(".share_mine").fadeOut();
    })
    $(".share_icon").on("click",function(e){
        $(".share_act").fadeIn().find(".share_c").addClass("show")
    });
    $(".share_act").on("click",function(e){
        var $tar = $(e.target);
        if($tar[0].nodeName.toLowerCase()!="a"){
            $(this).find(".share_c").removeClass("show").parent().fadeOut();
        }
    });
    /*��Ƭ����*/
    $(".activity_result_live .item img,.activity_result .item img").on("click",function(e){
        var $tar = $(e.target);
        var src = $tar.data("src");
        var word = $tar.parent().find(".word").html();
        $(".share_mine img").attr("src",src);
        $(".share_mine p").html(word);
        $(".share_mine").fadeIn();
    });
});