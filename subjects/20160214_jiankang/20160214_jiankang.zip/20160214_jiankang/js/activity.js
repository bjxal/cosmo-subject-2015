$(document).ready(function(){
    //���ذ�ť
    $(".top,.tit").on("click",function(e){
        var $tar = $(e.target);
        if($tar[0].nodeName.toLowerCase()=="a") return;
        history.back(-1);
    })
    /*activity_enroll*/
    $(".show_all").on("touchend",function(e){
        var $tar = $(e.target);
        var cname = $tar.attr("class");
        if(cname.indexOf("down")!=-1){
            $tar.removeClass("down").addClass("up");
            $tar.parents(".apply").addClass("showAll");
        }
        if(cname.indexOf("up")!=-1){
            $tar.removeClass("up").addClass("down");
            $tar.parents(".apply").removeClass("showAll");
        }
    })
    /*��һ��*/
    $(".login_btn").on("click",function(e){
        var $tar = $(e.target);
        var sure_code = $tar.data("sure");
        if(sure_code=="pay"){
            $(".pop").find(".reg_login_tip div").html("��ѡ��֧����ʽ").parents(".pop").fadeIn();
            return;
        }
        else if(sure_code=="pay_status"){
            $(".pop").fadeIn();
            return;
        }
        var nextUrl = $tar.data("nexturl");
        var ajax = $tar.data("ajax");
        var tips = $tar.data("tips");
        var $par = $tar.parents("body");
        if(nextUrl){
            window.location.href=nextUrl+".html";
        }
        else if(ajax){
            $par.find(".tips").fadeIn();
        }
        else if(tips){
            $par.find(".tips").fadeIn();
        }
    })
    //�û�Э��
    $(".reg_agree").on("click",function(e){
        $(e.target).toggleClass("cur");
    });
    //ɾ��
    $(".info_v .sel_btn").on("click",function(e){
        var $tar = $(e.target);
        $tar.parents(".list").addClass("del");
    });
    //�Ż���
    $(".promo").on("click",function(e){
        var val = $("#promo_code").val();
        if(val=="")
            $(".pop").find(".reg_login_tip div").html("����д�Ż���").parents(".pop").fadeIn();
    });
    //֧����ʽ
    $(".pay_list .sel_btn").on("click",function(e){
        var $tar = $(e.target);
        $(".item").find(".sel_btn").removeClass("cur");
        $tar.addClass("cur");
    });
    //��ά��
    $(".ewm").on("click",function(e){
        var $tar = $(e.target);
        var url = $tar.data("imgurl");
        $(".ewm_c img").attr("src",url);
        $(".pop.ewm_c").fadeIn();
    });
    /*activity_promo*/
    $(".phone").on("click",function(e){
        var $tar = $(e.target);
        var $par = $tar.parents("body");
        $par.find(".tips").fadeIn();
    })
    $(".pop").on("click",function(e){
        $(this).fadeOut();
    })
    /*����*/
    $(".share_mine").on("touchend",function(e){
        $(".share_mine").fadeOut();
    })
    $(".share_icon").on("click",function(e){
        $(".share_act").fadeIn().find(".share_c").addClass("show")
    });
    $(".share_act").on("click",function(e){
        var $tar = $(e.target);
        if($tar[0].nodeName.toLowerCase()!="a"){
            $(this).find(".share_c").removeClass("show").parent().fadeOut();
        }
    });
    /*birth*/
    sel = "sex";
    $par_c = {};
    $(".sel_arr").on("click",function(e){
        var $tar = $(e.target);
        sel = $tar.data("sel");
        $par_c = $tar.parents(".apply");
        $(".btm_sel").fadeIn();
        if(sel=="sex"){
            $(".btm_sel").find(".sex_sel").addClass("show");
        }
        else if(sel=="birthday"){
            $(".btm_sel").find(".birthday_sel").addClass("show");
        }
        $tar.fadeOut();
    })
    $(".selectEnd").on("click",function(e){
        var $tar = $(e.target);
        var tag = $tar.data("tag");
        var val = "";
        if(tag=="sex"){
            val = $("#demo_dummy").val();
        }
        else if(tag=="birthday"){
            val = $("#datetimeDate-demo").val().replace(/\//g,".");
        }
        $par_c.find(".user_"+sel).html(val).parents("."+sel).parents("body").find(".btm_sel").fadeOut().find("."+sel+"_sel").removeClass("show");
    });
    /*close select*/
    $(".btm_sel").on("click",function(e){
        var $tar = $(e.target);
        var cname = $tar.attr("class");
        if(cname.indexOf("item_sel")==-1){
            $(this).find(".show").removeClass("show");
            $(this).fadeOut();
        }
    })
})
$(function(){
    if($('#demo').length>0){
        var demoContainer = $('.demo-wrapper-datetimeDate');
        demoContainer.show();

        $('#demo').mobiscroll().select({
            theme: 'mobiscroll',
            lang: "zh",
            display: 'inline',
//			minWidth: 200,
            mode: "datetimeDate"
        });
    }
    if($('#datetimeDate-demo').length>0){
        $('#datetimeDate-demo').mobiscroll().date({
            theme: "ios",
            lang: "zh",
            display: "inline",
            mode: "datetimeDate"
        });
    }
});