$(document).ready(function(e){
    //���ذ�ť
    $(".top,.tit").on("click",function(e){
        var $tar = $(e.target);
        if($tar[0].nodeName.toLowerCase()=="a") return;
        history.back(-1);
    })
    //�ǳ�
    var name_input = 0;
    $("#name_v").on("focus",function(e){
        if(name_input==0){
            $(".name_tips").fadeIn();
            name_input = 1;
        }
    })
    //�û�Э��
    $(".reg_agree").on("click",function(e){
        $(e.target).toggleClass("cur");
    });
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
    //�趨����
    $(".login_btn").on("click",function(e){
        var $tar = $(e.target);
        var sure_code = $tar.data("sure");
        if(sure_code=="login"){
            var phoneNum = $("#phoneNum").val();
            var pwd = $("#pwd").val();
            if(phoneNum=="" || !myreg.test(phoneNum)){
                $(".login_tip").html("����д��ȷ���ֻ�����").addClass("show");
                return;
            }
            else if(pwd==""){
                $(".login_tip").html("���벻��Ϊ��").addClass("show");
                return;
            }
        }
        else if(sure_code=="pwd"){
            var pwd = $("#pwd").val();
            var pwd_sure = $("#pwd_sure").val();
            if(pwd!=pwd_sure){
                $(".login_tip").html("�������벻һ��").addClass("show");
                return;
            }
            else if(pwd=="" || pwd_sure==""){
                $(".login_tip").html("���벻��Ϊ��").addClass("show");
                return;
            }
        }
        else if(sure_code=="reg_info"){
            var phoneNum = $("#phoneNum").val();
            var code = $("#code").val();
            if(phoneNum=="" || !myreg.test(phoneNum)){
                $(".login_tip").html("����д��ȷ���ֻ�����").addClass("show");
                return;
            }
            if(code==""){
                $(".login_tip").html("��֤�벻��Ϊ��").addClass("show");
                return;
            }
            if(phoneNum!=""){
                $(".login_tip").html("").removeClass("show");
                $(".pop").fadeIn();
                return;
            }
        }
        else if(sure_code=="code"){
            var code = $("#code").val();
            if(code==""){
                $(".login_tip").html("��֤�벻��Ϊ��").addClass("show");
                return;
            }
        }
        else if(sure_code=="reg"){
            $(".reg_tips").fadeIn().find("a").attr("href","#");
            var num = 3;
            var id = setInterval(function(){
                if(num<1){
                    clearInterval(id);
                    //window.loaction.href="";//��ת��ע��ǰҳ��
                }
                $(".reg_tips span").html(num);
                num--;
            },1000);
        }
        var nextUrl = $tar.data("nexturl");
        if(nextUrl){
            window.location.href=nextUrl+".html";
        }
    });
    $(".user_info .login_btn").on("click",function(e){
        $(".pop").fadeIn();
    })
    /*������֤*/
    $("#phoneNum").on("input",function(e){
        var num = $(this).val();
        $(this).next().attr("href","sms:"+num);
    })
    //ɾ����������Ϣ
    $(".del_info").on("click",function(){
        $(".pop").fadeOut();
        $(".info").find("input").val("").parents(".info").find(".user_sex").html("");
    });
    /*delete*/
    $(".del_btn").on("click",function(e){
        var $tar = $(e.target);
        var $par = $tar.parents("body");
        $par.find(".tips").fadeIn();
    });
    $(".close_tip").on("click",function(e){
        var $tar = $(e.target);
        var $par = $tar.parents("body");
        $par.find(".pop").fadeOut();
    })
    /*birth*/
    sel = "sex";
    $(".sel_arr").on("click",function(e){
        var $tar = $(e.target);
        sel = $tar.data("sel");
        $(".btm_sel").fadeIn().find("."+sel+"_sel").addClass("show");
        //$(".btm_sel")
    })
    $(".selectEnd").on("click",function(e){
        var $tar = $(e.target);
        var tag = $tar.data("tag");
        var val = "";
        if(tag=="sex"){
            val = $("#sex_dummy").val();
            if(val=="��" && $("#ImgPr").length>0){
                var src = $("#ImgPr").attr("src").replace("women","men");
                $("#ImgPr").attr("src",src);
            }
        }
        else if(tag=="birthday"){
            var date = new Date();
            var today = date.getFullYear()+"."+(date.getMonth()+1)+"."+date.getDate();
            val = $("#datetimeDate-demo").val().replace(/\//g,".")||today;
        }
        else if(tag=="city"){
            val = $("#city_dummy").val();
        }
        $(this).parents("body").find(".user_"+sel).html(val).parents("."+sel).find(".sel_arr").hide().parents("body").find(".btm_sel").fadeOut().find("."+sel+"_sel").removeClass("show");
    });
    /*close select*/
    //$(".btm_sel").on("click",function(e){
    //    var $tar = $(e.target);
    //    var cname = $tar.attr("class");
    //    if(cname.indexOf("item_sel")==-1){
    //        $(this).find(".show").removeClass("show");
    //        $(this).fadeOut();
    //    }
    //})
});
$(function(){
    var body_cname = $("body").attr("class");
    if(body_cname=="users_info"){
        setCity();
        //select city
        $('#city').mobiscroll().select({
            theme: 'mobiscroll',
            display: 'inline',
            label: 'City',
            group: true,
            groupLabel: 'Country',
            fixedWidth: [100, 170]
        });
        //select sex
        $('#sex').mobiscroll().select({
            theme: 'mobiscroll',
            lang: "zh",
            display: 'inline',
//			minWidth: 200,
            mode: "datetimeDate"
        });
        //select date
        var demoContainer = $('.demo-wrapper-datetimeDate');
        demoContainer.show();
        $('#datetimeDate-demo').mobiscroll().date({
            theme: "ios",
            lang: "zh",
            display: "inline",
            mode: "datetimeDate"
        });
    }
    else if(body_cname=="users_info users_edit_info" || body_cname=="activity_apply activity_enroll"){
        //select sex
        $('#sex').mobiscroll().select({
            theme: 'mobiscroll',
            lang: "zh",
            display: 'inline',
//			minWidth: 200,
            mode: "datetimeDate"
        });
    }
    /*���ӱ�����*/
    $(".users_add .sel_btn").on("click",function(e){
        $(this).toggleClass("cur");
    });
    //Ԥ��ͼƬ
    if($("#up").length>0){
        $("#up").uploadPreview({ Img: "ImgPr", Width: 236, Height: 236 });
    }
});
//set city Dom
function setCity(){
    var dom = "";
    $.each(city,function(i,item){
        dom += '<optgroup label="'+item.name+'">';
        $.each(item.child,function(j,item_j){
            dom += '<option value="'+item_j+'">'+item_j+'</option>';
        })
    })
    $("#city").append(dom)
}