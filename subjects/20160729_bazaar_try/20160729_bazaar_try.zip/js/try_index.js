$(document).ready(function(){
    var iswiperCont = $('.index-swiper');
    var indexSwiper = new Swiper('.swiper-container.index-swiper', {
        pagination: '.swiper-pagination',
        paginationClickable: true,
        spaceBetween: 30,
        //autoplay: 4000,
        loop: true
    });
    iswiperCont.find('.swiper-button-prev').on('click', function(e){
        e.preventDefault();
        indexSwiper.swipePrev();
    });
    iswiperCont.find('.swiper-button-next').on('click', function(e){
        e.preventDefault();
        indexSwiper.swipeNext();
    });

    iswiperCont.mouseenter(function(){
        indexSwiper.stopAutoplay();
    });
    iswiperCont.mouseleave(function(){
        indexSwiper.startAutoplay();
    });

});