/*watch*/
var watch_list = [
    {
        'height': '710px',
        'width': '790px',
        'content': '<div class="imgs imgs_1"><img src="img-subject/p1/list/1.jpg"/><div class="word cur"><h2>压轴的LV女郎们酷毙了！</h2><p>搭配浪漫唯美的木耳边装饰宫廷风格衬衫，或是摩登时髦的网眼背心，如绅士般潇洒，胸口处的小面积镂空在之前的系列中也曾使用过1</p></div></div>'//ImgDir('/p1/list/1.jpg')
    },
    {
        'height': '710px',
        'width': '790px',
        'content': '<div class="imgs imgs_2"><img src="img-subject/p1/list/2.jpg"/><div class="word"><h2>压轴的LV女郎们酷毙了！</h2><p>搭配浪漫唯美的木耳边装饰宫廷风格衬衫，或是摩登时髦的网眼背心，如绅士般潇洒，胸口处的小面积镂空在之前的系列中也曾使用过；那些长度只及下胸2</p></div></div>'//ImgDir('/p1/list/1.jpg')
    },
    {
        'height': '710px',
        'width': '790px',
        'content': '<div class="imgs imgs_3"><img src="img-subject/p1/list/3.jpg"/><div class="word"><h2>压轴的LV女郎们酷毙了！</h2><p>搭配浪漫唯美的木耳边装饰宫廷风格衬衫，或是摩登时髦的网眼背心，如绅士般潇洒，胸口处的小面积镂空在之前的系列中也曾使用过；那些长度只及下胸线的短上衣与卖弄柔弱性感。；那些长度只及下胸线的短上衣与卖弄柔弱性感。3</p></div></div>'//ImgDir('/p1/list/1.jpg')
    },
    {
        'height': '710px',
        'width': '790px',
        'content': '<div class="imgs"><img src="img-subject/p1/list/4.jpg"/><div class="word"><h2>压轴的LV女郎们酷毙了！</h2><p>搭配浪漫唯美的木耳边装饰4</p></div></div>'
    }
];
/*star*/
var star_list = [
    {
        width:520,
        height:800,
        content:ImgDir('/p2/list/1.jpg')
    },
    {
        width:520,
        height:800,
        content:ImgDir('/p2/list/2.jpg')
    },
    {
        width:520,
        height:800,
        content:ImgDir('/p2/list/3.jpg')
    }
];
/*guests*/
var guests_list_lf = [
    {
        imgUrl:ImgDir('/p3/list/lf_1.jpg'),
        name:"妮可·基德曼"
    },
    {
        imgUrl:ImgDir('/p3/list/lf_2.jpg'),
        name:"艾薇儿"
    }
];
var guests_list_rt = [
    {
        imgUrl:ImgDir('/p3/list/rt_1.jpg'),
        name:"徐若瑄"
    },
    {
        imgUrl:ImgDir('/p3/list/rt_2.jpg'),
        name:"郭碧婷"
    }
];

/*icon*/
var icon_list_lf = [
    {
        imgUrl:ImgDir('/p4/list/1.jpg'),
        name:"范冰冰",
        info:"电影演员，毕业于上海师范大学谢晋影视艺术学院。1996年参演电视剧《女强人》。"
    },
    {
        imgUrl:ImgDir('/p4/list/2.jpg'),
        name:"汤唯",
        info:"中央戏剧学院导演系本科。2007年在导演李安执导的电影《色·戒》中饰演女主角。"
    },
    {
        imgUrl:ImgDir('/p4/list/3.jpg'),
        name:"Angelababy",
        info:"1989年2月28日出生于上海，13岁时移居香港，中国影视女演员。"
    },
    {
        imgUrl:ImgDir('/p4/list/2.jpg'),
        name:"汤唯",
        info:"中央戏剧学院导演系本科。2007年在导演李安执导的电影《色·戒》中饰演女主角。"
    }
];

/*moment*/

/*team*/