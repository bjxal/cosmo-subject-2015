/*watch*/
var watch_list_1 = [{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""}];
var watch_list = [];
$.each(watch_list_1,function(i,item){
    var aa = {};
    aa.width = "710px";
    aa.height = "790px";
    var cur = (i==0)?"cur":"";
    aa.content = '<div class="imgs"><img src="'+item.pic+'"/><div class="word '+cur+'"><h2>'+item.title+'</h2><p>'+item.digest+'</p></div></div>';
    watch_list.push(aa);
});
/*star*/
var star_list_1 = [{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""}];
var star_list = [];
$.each(star_list_1,function(i,item){
    var aa = {};
    aa.width = 520;
    aa.height = 800;
    aa.content = item.pic;
    star_list.push(aa);
});
/*guests*/
var guests_list = [{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""}];

/*icon*/
var icon_list = [{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""}];

/*moment*/
var moment_list = [{"id":"2623","title":"gfdhdfg","url":"","classid":"2154","module_id":"617","digest":"fdfhfj","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f7f37f33_871.jpg","pic2":"","date":"2015-10-22 10:52:26","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2623","title":"gfdhdfg","url":"","classid":"2154","module_id":"617","digest":"fdfhfj","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f7f37f33_871.jpg","pic2":"","date":"2015-10-22 10:52:26","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2623","title":"gfdhdfg","url":"","classid":"2154","module_id":"617","digest":"fdfhfj","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f7f37f33_871.jpg","pic2":"","date":"2015-10-22 10:52:26","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2623","title":"gfdhdfg","url":"","classid":"2154","module_id":"617","digest":"fdfhfj","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f7f37f33_871.jpg","pic2":"","date":"2015-10-22 10:52:26","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2623","title":"gfdhdfg","url":"","classid":"2154","module_id":"617","digest":"fdfhfj","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f7f37f33_871.jpg","pic2":"","date":"2015-10-22 10:52:26","location":"2","status":"0","is_checked":"0","checked_man":""}];
/*team*/
var team_list = [{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""},{"id":"2622","title":"fdgfh","url":"","classid":"2154","module_id":"616","digest":"dsgtfh","pic":"http:\/\/new-img1.cosmochina.com.cn\/cosmo\/moudlepic\/2154_module_images\/201510\/56284f5f77e9e_732.jpg","pic2":"","date":"2015-10-22 10:52:00","location":"2","status":"0","is_checked":"0","checked_man":""}];

/*set data*/
LIST = function(){}
LIST.prototype = {
    set_watch_list:function(){
        var islider1 = new iSlider({
            data: watch_list,
            type:"dom",
            dom: document.getElementById("animation-effect"),
            duration: 3000,
            animateType: 'rotate',
            isAutoplay: false,
            isLooping: true,
            onslideend:function(){
                var list = $("#animation-effect li");
                $.each(list,function(i,item){
                    var deg_v = $(item).attr("style").split("rotateY(")[1].split("deg")[0];
                    if(deg_v==0){
                        $(item).find(".word").addClass("cur");
                    }
                    else{
                        $(item).find(".word").removeClass("cur");
                    }
                });
            }
            //isVertical: true// 是否垂直滚动
        });
    },
    set_star_list:function(){
        var me = this;
        me.star_html();
        var islider2 = new iSlider({
            data: star_list,
            //type:'dom',
            dom: document.getElementById("animation-effect-2"),
            duration: 3000,
            animateType: 'flow',
            isAutoplay: false,
            isLooping: true,
            onslideend:function(){
                var id = islider2.slideIndex;
                $(".p2 .name-list p").eq(id).addClass("cur").siblings().removeClass("cur");

            }
            //isVertical: true// 是否垂直滚动
        });
    },
    star_html:function(){
        var me = this;
        var name = "";
        $.each(star_list,function(i,item){
            var cname = (i==0)?"cur":"";
            name += '<p class="'+cname+'">'+item.title+'</p>';
        });
        $(".p2 .name-list").html(name);
    },
    set_guests_list:function(){
        var me = this;
        /*lf*/
        var name = "";
        $.each(guests_list,function(i,item){
            var id = i%2+1;
            var cname = (i==0)?"cur":"";
            var lf_html = me.guests_html(item,i);
            $(".p3 .list-c-"+id).append(lf_html);
            name += '<p class="'+cname+'">'+item.title+'</p>';
        });
        $(".p2 .name-list").html(name);
    },
    guests_html:function(obj,i){
        var c = document.createElement("div");
        var cname = (i<2)?"cur":"";
        //c.className = (i==0)?"list-c-item cur":"list-c-item";
        c.className = "list-c-item item-"+Math.floor(i/2)+" "+cname;

        var c_img = document.createElement("img");
        c_img.src = obj.pic;
        c.appendChild(c_img);

        var c_name = document.createElement("div");
        c_name.className = "name";
        c_name.innerHTML = obj.title;
        c.appendChild(c_name);

        return c;
    },
    guests_name_html:function(obj,i){
    },
    set_icon_list:function(){
        var me = this;
        $.each(icon_list,function(i,item){
            var id = i%4+1;
            var icon_html = me.icon_html(item,i);
            $(".p4 .list-c-"+id).append(icon_html);
        });
    },
    icon_html:function(obj,i){
        var cname = (i<4)?"cur":"";
        var c = document.createElement("div");
        c.className = "item-c item-"+Math.floor(i/4)+" "+cname;

        var c_avt = document.createElement("div");
        c_avt.className = "c-avt";
        c_avt.innerHTML = '<img src="'+obj.pic+'"/>';
        c.appendChild(c_avt);

        var c_info = document.createElement("div");
        c_info.className = "c-info";
        c_info.innerHTML = '<h2>'+obj.title+'</h2><p>'+obj.digest+'</p>';
        c.appendChild(c_info);

        var c_line = document.createElement("div");
        c_line.className = "c-line";
        c_line.innerHTML = '<span class="line_1"></span><span class="line_2"></span>';
        c.appendChild(c_line);

        return c;

    },
    set_moment_list:function(){
        var me = this;
        $.each(moment_list,function(i,item){
            var id = i%5+1;
            var moment_html = me.moment_html(item,i);
            $(".p5 .list-c-"+id).append(moment_html);
        });
    },
    moment_html:function(obj,i){
        var cname = (i<5)?"cur":"";
        var c = document.createElement("img");
        c.src = obj.pic;
        c.className = "item-c item-"+Math.floor(i/5)+" "+cname;

        return c;
    },
    set_team_list:function(){
        var me = this;
        $.each(team_list,function(i,item){
            var id = i%12+1;
            var team_html = me.team_html(item,i);
            $(".p6 .list-c-"+id).append(team_html);
        });
    },
    team_html:function(obj,i){
        var cname = (i<12)?"cur":"";
        var c = document.createElement("div");
        c.className = "list-item item-"+Math.floor(i/12)+" "+cname;
        c.innerHTML = '<img src="'+obj.pic+'"/><div class="name"><p><span>'+obj.title+'</span></p></div>';

        return c;
    }
};