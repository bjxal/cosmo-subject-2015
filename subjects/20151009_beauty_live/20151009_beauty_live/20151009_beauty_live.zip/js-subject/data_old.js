/*watch*/
var watch_list = [
    {
        'height': '710px',
        'width': '790px',
        'content': '<div class="imgs imgs_1"><img src="img-subject/p1/list/1.jpg"/><div class="word cur"><h2>压轴的LV女郎们酷毙了！</h2><p>搭配浪漫唯美的木耳边装饰宫廷风格衬衫，或是摩登时髦的网眼背心，如绅士般潇洒，胸口处的小面积镂空在之前的系列中也曾使用过1</p></div></div>'//ImgDir('/p1/list/1.jpg')
    },
    {
        'height': '710px',
        'width': '790px',
        'content': '<div class="imgs imgs_2"><img src="img-subject/p1/list/2.jpg"/><div class="word"><h2>压轴的LV女郎们酷毙了！</h2><p>搭配浪漫唯美的木耳边装饰宫廷风格衬衫，或是摩登时髦的网眼背心，如绅士般潇洒，胸口处的小面积镂空在之前的系列中也曾使用过；那些长度只及下胸2</p></div></div>'//ImgDir('/p1/list/1.jpg')
    },
    {
        'height': '710px',
        'width': '790px',
        'content': '<div class="imgs imgs_3"><img src="img-subject/p1/list/3.jpg"/><div class="word"><h2>压轴的LV女郎们酷毙了！</h2><p>搭配浪漫唯美的木耳边装饰宫廷风格衬衫，或是摩登时髦的网眼背心，如绅士般潇洒，胸口处的小面积镂空在之前的系列中也曾使用过；那些长度只及下胸线的短上衣与卖弄柔弱性感。；那些长度只及下胸线的短上衣与卖弄柔弱性感。3</p></div></div>'//ImgDir('/p1/list/1.jpg')
    },
    {
        'height': '710px',
        'width': '790px',
        'content': '<div class="imgs"><img src="img-subject/p1/list/4.jpg"/><div class="word"><h2>压轴的LV女郎们酷毙了！</h2><p>搭配浪漫唯美的木耳边装饰4</p></div></div>'
    }
];
/*star*/
var star_list = [
    {
        width:520,
        height:800,
        content:ImgDir('/p2/list/1.jpg')
    },
    {
        width:520,
        height:800,
        content:ImgDir('/p2/list/2.jpg')
    },
    {
        width:520,
        height:800,
        content:ImgDir('/p2/list/3.jpg')
    }
];
var star_list_1 = [
    {
        title:"范冰冰"
    },
    {
        title:"李冰冰"
    },
    {
        title:"舒淇"
    }
]
/*guests*/
var guests_list = [
    {
        pic:ImgDir('/p3/list/lf_1.jpg'),
        title:"妮可·基德曼"
    },
    {
        pic:ImgDir('/p3/list/lf_2.jpg'),
        title:"艾薇儿"
    },
    {
        pic:ImgDir('/p3/list/rt_1.jpg'),
        title:"徐若瑄"
    },
    {
        pic:ImgDir('/p3/list/rt_2.jpg'),
        title:"郭碧婷"
    }
];

/*icon*/
var icon_list = [
    {
        pic:ImgDir('/p4/list/1.jpg'),
        title:"范冰冰",
        digest:"电影演员，毕业于上海师范大学谢晋影视艺术学院。1996年参演电视剧《女强人》。"
    },
    {
        pic:ImgDir('/p4/list/2.jpg'),
        title:"汤唯",
        digest:"中央戏剧学院导演系本科。2007年在导演李安执导的电影《色·戒》中饰演女主角。"
    },
    {
        pic:ImgDir('/p4/list/3.jpg'),
        title:"Angelababy",
        digest:"1989年2月28日出生于上海，13岁时移居香港，中国影视女演员。"
    },
    {
        pic:ImgDir('/p4/list/2.jpg'),
        title:"汤唯",
        digest:"中央戏剧学院导演系本科。2007年在导演李安执导的电影《色·戒》中饰演女主角。"
    },
    {
        pic:ImgDir('/p4/list/5.jpg'),
        title:"安吉丽娜·朱莉",
        digest:"1975年6月4日出生于美国洛杉矶，好莱坞电影明星、社会活动家、联合国高级难民署特使。"
    },
    {
        pic:ImgDir('/p4/list/6.jpg'),
        title:"高圆圆",
        digest:"中国女演员，1979年10月5日出生于北京市丰台区云岗一个普通的知识分子家庭。"
    },
    {
        pic:ImgDir('/p4/list/7.jpg'),
        title:"唐嫣",
        digest:"1983年12月6日出生于上海，中国女演员。2006年毕业于中央戏剧学院表演系本科班。"
    },
    {
        pic:ImgDir('/p4/list/8.jpg'),
        title:"杨幂",
        digest:"1986年9月12日出生于北京，毕业于北京电影学院表演系2005级本科班。中国女演员、歌手、电视剧制片人。"
    }
];

/*moment*/
var moment_list = [
    {
        pic:ImgDir('/p5/list/1.jpg')
    },
    {
        pic:ImgDir('/p5/list/2.jpg')
    },
    {
        pic:ImgDir('/p5/list/3.jpg')
    },
    {
        pic:ImgDir('/p5/list/4.jpg')
    },
    {
        pic:ImgDir('/p5/list/5.jpg')
    },
    {
        pic:ImgDir('/p5/list/6.jpg')
    },
    {
        pic:ImgDir('/p5/list/7.jpg')
    },
    {
        pic:ImgDir('/p5/list/8.jpg')
    },
    {
        pic:ImgDir('/p5/list/9.jpg')
    },
    {
        pic:ImgDir('/p5/list/10.jpg')
    }
];
/*team*/
var team_list = [
    {
        pic:ImgDir('/p6/list/1.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/2.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/3.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/4.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/5.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/6.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/7.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/8.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/9.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/10.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/11.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/12.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/13.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/14.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/15.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/16.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/17.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/18.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/19.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/20.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/21.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/22.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/23.jpg'),
        title:"Aaria arredondo"
    },
    {
        pic:ImgDir('/p6/list/24.jpg'),
        title:"Aaria arredondo"
    }
];
LIST = function(){};
LIST.prototype = {
    set_watch_list:function(){
        var islider1 = new iSlider({
            data: watch_list,
            type:"dom",
            dom: document.getElementById("animation-effect"),
            duration: 3000,
            animateType: 'rotate',
            isAutoplay: false,
            isLooping: true,
            onslideend:function(){
                var list = $("#animation-effect li");
                $.each(list,function(i,item){
                    var deg_v = $(item).attr("style").split("rotateY(")[1].split("deg")[0];
                    if(deg_v==0){
                        $(item).find(".word").addClass("cur");
                    }
                    else{
                        $(item).find(".word").removeClass("cur");
                    }
                });
            }
            //isVertical: true// 是否垂直滚动
        });
    },
    set_star_list:function(){
        var me = this;
        me.star_html();
        var islider2 = new iSlider({
            data: star_list,
            //type:'dom',
            dom: document.getElementById("animation-effect-2"),
            duration: 3000,
            animateType: 'flow',
            isAutoplay: false,
            isLooping: true,
            onslideend:function(){
                var id = islider2.slideIndex;
                $(".p2 .name-list p").eq(id).addClass("cur").siblings().removeClass("cur");

            }
            //isVertical: true// 是否垂直滚动
        });
    },
    star_html:function(){
        var me = this;
        var name = "";
        $.each(star_list_1,function(i,item){
            var cname = (i==0)?"cur":"";
            name += '<p class="'+cname+'">'+item.title+'</p>';
        });
        $(".p2 .name-list").html(name);
    },
    set_guests_list:function(){
        var me = this;
        /*lf*/
        $.each(guests_list,function(i,item){
            var id = i%2+1;
            var lf_html = me.guests_html(item,i);
            $(".p3 .list-c-"+id).append(lf_html);
        });
    },
    guests_html:function(obj,i){
        var c = document.createElement("div");
        var cname = (i<2)?"cur":"";
        //c.className = (i==0)?"list-c-item cur":"list-c-item";
        c.className = "list-c-item item-"+Math.floor(i/2)+" "+cname;

        var c_img = document.createElement("img");
        c_img.src = obj.pic;
        c.appendChild(c_img);

        var c_name = document.createElement("div");
        c_name.className = "name";
        c_name.innerHTML = obj.title;
        c.appendChild(c_name);

        return c;
    },
    set_icon_list:function(){
        var me = this;
        $.each(icon_list,function(i,item){
            var id = i%4+1;
            var icon_html = me.icon_html(item,i);
            $(".p4 .list-c-"+id).append(icon_html);
        });
    },
    icon_html:function(obj,i){
        var cname = (i<4)?"cur":"";
        var c = document.createElement("div");
        c.className = "item-c item-"+Math.floor(i/4)+" "+cname;

        var c_avt = document.createElement("div");
        c_avt.className = "c-avt";
        c_avt.innerHTML = '<img src="'+obj.pic+'"/>';
        c.appendChild(c_avt);

        var c_info = document.createElement("div");
        c_info.className = "c-info";
        c_info.innerHTML = '<h2>'+obj.title+'</h2><p>'+obj.digest+'</p>';
        c.appendChild(c_info);

        var c_line = document.createElement("div");
        c_line.className = "c-line";
        c_line.innerHTML = '<span class="line_1"></span><span class="line_2"></span>';
        c.appendChild(c_line);

        return c;

    },
    set_moment_list:function(){
        var me = this;
        $.each(moment_list,function(i,item){
            var id = i%5+1;
            var moment_html = me.moment_html(item,i);
            $(".p5 .list-c-"+id).append(moment_html);
        });
    },
    moment_html:function(obj,i){
        var cname = (i<5)?"cur":"";
        var c = document.createElement("img");
        c.src = obj.pic;
        c.className = "item-c item-"+Math.floor(i/5)+" "+cname;

        return c;
    },
    set_team_list:function(){
        var me = this;
        $.each(team_list,function(i,item){
            var id = i%12+1;
            var team_html = me.team_html(item,i);
            $(".p6 .list-c-"+id).append(team_html);
        });
    },
    team_html:function(obj,i){
        var cname = (i<12)?"cur":"";
        var c = document.createElement("div");
        c.className = "list-item item-"+Math.floor(i/12)+" "+cname;
        c.innerHTML = '<img src="'+obj.pic+'"/><div class="name"><p><span>'+obj.title+'</span></p></div>';
        return c;
    }
};