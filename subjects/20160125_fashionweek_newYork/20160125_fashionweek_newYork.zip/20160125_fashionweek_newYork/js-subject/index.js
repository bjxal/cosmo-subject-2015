require("/fliza-ui");
var p3 = [
    ImgDir('/p3/1.jpg'),
    ImgDir('/p3/2.jpg'),
    ImgDir('/p3/1.jpg'),
    ImgDir('/p3/2.jpg')
];
var content = encodeURIComponent('2016ŦԼʱװ��'),
    title  = '',
    pic   = ImgDir('/weixin.jpg'),
    url   = '';//encodeURIComponent('http://m.durex.com.cn/qr/1N'),
    back  = encodeURIComponent('http://m.cosmopolitan.com.cn/');
    tourl = '';
//var url = "http://m.onlylady.com/files/eventapi.php?c=EventNew&a=ZST&indexsId=618";
move_m = false;
grade = 0;
var p6_id = 0;
Fui.Template.IMG_DIR = ImgDir();
var PAGE0 = Fui.Template.extend({
    config:{
    },
    design:function(){
        $(".fui-arrow").hide();
    }
    ,getGestureItems:function(){
        return[
            {
                gesture:"tap",
                name:"toPage",
                callback:function(e,$tar){
                    e.preventDefault();
                    var id = $tar.data("id")||1;
                    slider.toPage(id);
                }
            },
            {
                gesture:"tap",
                name:"p5_pop",
                callback:function(e,$tar){
                    e.preventDefault();
                    var id = $tar.data("id");
                    $(".p5 .img_c").find("img").eq(id).addClass("cur").siblings().removeClass("cur");
                }
            },
            {
                gesture:"tap",
                name:"c-btn-tap-3",
                callback:function(e,$tar){
                    e.preventDefault();
                    var num = (street_list.length)/2;
                    p6_id = ((p6_id+1)<num)?(p6_id+1):0;
                    $tar.parents(".p").find(".item-"+p6_id).addClass("cur zIndex cur_"+p6_id);
                    $tar.parents(".p").find(".list-c-item.cur_"+p6_id).siblings().removeClass("zIndex");
                    setTimeout(function(){
                        $tar.parents(".p").find(".list-c-item.cur_"+p6_id).siblings().removeClass("cur");
                    },600);
                }
            },
            {
                gesture:"tap",
                name:"share_pop_show",
                callback:function(e,$tar){
                    e.preventDefault();
                    $(".share_pop").fadeIn();
                    slider.set("lock","true");
                }
            },
            {
                gesture:"tap",
                name:"share_pop_hide",
                callback:function(e,$tar){
                    e.preventDefault();
                    $(".share_pop").fadeOut();
                    slider.set("lock","false");
                }
            },
            {
                gesture:"tap",
                name:"share_sina",
                callback:function(e,$tar){
                    e.preventDefault();
                    tourl = 'http://service.weibo.com/share/mobile.php?title=$content&url=$url&pic=$pic&backurl=$back';
                    tourl = tourl.replace('$title',title).replace('$content',content).replace('$pic',pic).replace('$url',url).replace('$back',back);
                    window.open(tourl,'_blank');
                }
            },{
                gesture:"tap",
                name:"m_link",
                callback:function(e,$tar){
                    var url = "http://m.cosmopolitan.com.cn/";
                    window.open(url,'_blank');
                }
            },{
                gesture:"tap",
                name:"video_pop",
                callback:function(e,$tar){
                    var id = $tar.data("id");
                    //var videoUrl = $tar.data("url");
                    var videoUrl = video_list[id]['video'];
                    var ifr_video = '<iframe width="750" height="400" src="'+videoUrl+'" frameborder="0" allowfullscreen=""></iframe>';
                    $(".video_pop .video").html(ifr_video);
                    $(".video_pop").show();
                    $(".video_tit h2").eq(id).show().siblings().hide();
                    $(".cover_img img").eq(id).addClass("cur").siblings().removeClass("cur");
                    $(".thumb .pop").eq(id).addClass("cur").parents().siblings().find(".pop").removeClass("cur");
                }
            }
        ]
    }
});
Fui.Template.regTpl({
    PAGE0:PAGE0
});
var p3_one = 0;
var slider = new Fui.PageSlider({
    el:'#pack',
    curPage:0,
    lock:false,
    iteration:false,
    orient:'y',
    listeners:{
        slide:function(){
            move_t = false;
            var gesture = slider.event.gesture;
            $(".fui-arrow.right").hide();
            var page = this.get("curPage");
            $(".p"+page).addClass("focus");
            $("body").attr("class","bg_"+page);
            if(page==3 && p3_one==0){
                p3_one=1;
                setImgList();
                myScroll = new iScroll('wrapper',{
                    snap: true,
                    hScrollbar: false
                });
            }
            if(page==8){
                $(".fui-arrow").css("z-index","-1");
                $(".app-music").css("z-index","-1");
            }
            else{

                $(".fui-arrow").css("z-index","10000");
                $(".app-music").css("z-index","101");
            }
        }
    },
    data:[
        {
            template:'PAGE0',
            xtpl:'p0'
        }
        ,{
            template:'PAGE0',
            xtpl:'p1'
        }
        ,{
            template:'PAGE0',
            xtpl:'p2'
        }
        ,{
            template:'PAGE0',
            xtpl:'p3'
        }
        ,{
            template:'PAGE0',
            xtpl:'p4'
        }
        ,{
            template:'PAGE0',
            xtpl:'p5'
        }
        , {
            template: 'PAGE0',
            xtpl: 'p6'
        }
        , {
            template: 'PAGE0',
            xtpl: 'p7'
        }
        , {
            template: 'PAGE0',
            xtpl: 'p8'
        }
    ]
});
slider.render();
//$(".fui-arrow").css("z-index","-1");

/*set data*/
var list = new LIST();
/*bendi*/
list.set_news_list();
list.set_runway_list();
list.set_street_list();
list.set_backstage_list();
list.set_video_list();
//list.set_team_list();

//p4
//var islider1 = new iSlider({
//    data: picList,
//    dom: document.getElementById("animation-effect"),
//    duration: 3000,
//    animateType: 'rotate',
//    isAutoplay: false,
//    isLooping: true,
//     //isVertical: true// �Ƿ�ֱ����
//});

function setImgList(){
    //if(p2_num==0){
    //    p2_num = 1;
    //    $(".slide_tips").fadeIn();
    //    setTimeout(function(){$(".slide_tips").fadeOut();},1500);
    //}
    $("#scroller").css("width",(cele_list_1.length*560+50)+"px");
    $.each(cele_list_1,function(i,item){
        var li1 = '<li><img src="'+item.pic+'"/><div class="img_s"></div><div class="word"><h2>'+item.title+'</h2><p>'+item.digest+'</p></div></li>';
        $("#thelist").append(li1);
    });
}
$(".video_pop .close").bind("click",function(e){
    $(".video_pop").fadeOut().find("iframe").remove();
});